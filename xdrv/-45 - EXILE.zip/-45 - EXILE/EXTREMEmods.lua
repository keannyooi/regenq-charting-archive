INIT_BEAT = -15

function animateBorders(from_ratio, to_ratio, beat, length, ease)
    for _, direction in ipairs({"left", "right", "top", "bottom"}) do
        xdrv.Ease("black_bar_" .. direction .. "_position", from_ratio / 2, to_ratio / 2, "beat", beat, "len", length, ease)
    end
end

-- initialize camera pos
xdrv.Set("speed", 0.1, "beat", INIT_BEAT)
xdrv.Set("camera_position_z", 2, "beat", INIT_BEAT)
xdrv.Set("camera_rotation_x", 45, "beat", INIT_BEAT)
animateBorders(1, 1, INIT_BEAT, 0, "linear")

-- intro sequence, camera zooms out to tracks
xdrv.Ease("camera_position_y", -3, 0, "beat", 0, "len", 13, "linear")
xdrv.Ease("camera_rotation_y", -45, 45, "beat", 0, "len", 13, "linear")
animateBorders(1, 0.25, 0, 12, "outQuad")

-- transition into normal camera view
animateBorders(0.25, 1, 12, 1.5, "outQuart")
xdrv.Set("speed", 0.5, "beat", 13.5)
xdrv.Set("camera_position_y", -2, "beat", 13.5)
xdrv.Set("camera_position_z", -1.5, "beat", 13.5)
xdrv.Set("camera_rotation_x", -45, "beat", 13.5)
xdrv.Set("camera_rotation_y", 0, "beat", 13.5)
animateBorders(1, 0, 13.5, 1.5, "outQuart")

xdrv.Ease("speed", 0.5, 1, "beat", 30, "len", 2, "linear")
xdrv.Ease("camera_rotation_x", -45, 0, "beat", 30, "len", 2, "linear")
xdrv.Ease("camera_position_y", -2, 0, "beat", 30, "len", 2, "linear")
xdrv.Ease("camera_position_z", -1.5, 0, "beat", 30, "len", 2, "linear")

-- fov shenanigans to emphasize kick drums
for i = 32, 61, 1 do
    xdrv.Ease("camera_fov", 101.25, 100, "beat", i, "len", 1, "outCubic")
end

-- merge both lanes into a full 6k highway line
xdrv.Ease("trackleft_move_x", 0, 0.25, "beat", 62, "len", 2/3, "outQuad")
xdrv.Ease("trackright_move_x", 0, -0.25, "beat", 62 + 2/3, "len", 2/3, "outQuad")
xdrv.Ease("trackleft_move_x", 0.25, 0.5, "beat", 63 + 1/3, "len", 2/3, "outQuad")
xdrv.Ease("trackright_move_x", -0.25, -0.5, "beat", 63 + 1/3, "len", 2/3, "outQuad")

-- chart descends slowly from the 2nd checkpoint to the 3rd
xdrv.Ease("camera_position_y", 0, -5, "beat", 64, "len", 96, "linear")
xdrv.Ease("track_move_y", 0, -5, "beat", 64, "len", 96, "linear")

-- intensification
for i = 96, 159, 1 do
    xdrv.Ease("note_scale_x", 1.5, 1, "beat", i, "len", 1, "outQuart")
end

for i = 128, 154, 2 do
    xdrv.Ease("trackleft_move_z", 0.2, 0, "beat", i, "len", 1, "outQuart")
    xdrv.Ease("trackright_move_z", -0.2, 0, "beat", i, "len", 1, "outQuart")
    xdrv.Ease("trackleft_move_z", -0.2, 0, "beat", i + 1, "len", 1, "outQuart")
    xdrv.Ease("trackright_move_z", 0.2, 0, "beat", i + 1, "len", 1, "outQuart")
end

xdrv.Ease("note_scale_x", 1.5, 1, "beat", 157.5, "len", 1, "outQuart")
xdrv.Ease("note_scale_x", 1.5, 1, "beat", 158.5, "len", 1, "outQuart")

xdrv.Ease("trackleft_move_z", 0.2, 0, "beat", 156, "len", 1, "outQuart")
xdrv.Ease("trackright_move_z", -0.2, 0, "beat", 156, "len", 1, "outQuart")
xdrv.Ease("trackleft_move_z", -0.2, 0, "beat", 157, "len", 1, "outQuart")
xdrv.Ease("trackright_move_z", 0.2, 0, "beat", 157, "len", 1, "outQuart")

xdrv.Ease("trackleft_move_z", 0.2, 0, "beat", 157.5, "len", 1, "outQuart")
xdrv.Ease("trackright_move_z", -0.2, 0, "beat", 157.5, "len", 1, "outQuart")
xdrv.Ease("trackleft_move_z", -0.2, 0, "beat", 158.5, "len", 1, "outQuart")
xdrv.Ease("trackright_move_z", 0.2, 0, "beat", 158.5, "len", 1, "outQuart")

xdrv.Ease("trackleft_move_z", 0.2, 0, "beat", 159, "len", 1, "outQuart")
xdrv.Ease("trackright_move_z", -0.2, 0, "beat", 159, "len", 1, "outQuart")

-- break part
xdrv.Ease("trackleft_move_x", 0.5, 0.625, "beat", 160, "len", 1, "outQuad")
xdrv.Ease("trackright_move_x", -0.5, -0.625, "beat", 160, "len", 1, "outQuad")

xdrv.Ease("camera_rotation_x", 0, 22.5, "beat", 160, "len", 32, "linear")
xdrv.Ease("camera_position_y", -5, -3, "beat", 160, "len", 32, "linear")
xdrv.Ease("camera_position_z", 0, 3, "beat", 160, "len", 32, "linear")
xdrv.Ease("speed", 1, 0.75, "beat", 160, "len", 32, "linear")

xdrv.Ease("camera_position_y", -3, -8, "beat", 224, "len", 96, "linear")
xdrv.Ease("track_move_y", -5, -10, "beat", 224, "len", 96, "linear")

xdrv.Ease("black_bar_left_position", 0, 0.375, "beat", 288, "len", 24, "linear")
xdrv.Ease("black_bar_right_position", 0, 0.375, "beat", 288, "len", 24, "linear")